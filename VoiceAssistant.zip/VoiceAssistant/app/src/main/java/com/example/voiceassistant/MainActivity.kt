package com.example.voiceassistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import javax.net.ssl.HttpsURLConnection

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var conversationText: TextView
    private lateinit var statusText: TextView
    private lateinit var micButton: Button
    private lateinit var settingsButton: Button
    private lateinit var tts: TextToSpeech
    private lateinit var prefs: SharedPreferences

    private val conversation = StringBuilder()
    private val chatHistory = JSONArray() // stores {role, content} pairs sent to the API

    companion object {
        private const val SPEECH_REQUEST_CODE = 100
        private const val RECORD_AUDIO_PERMISSION_CODE = 200
        private const val PREFS_NAME = "voice_assistant_prefs"
        private const val KEY_API_KEY = "api_key"

        // Change this if you want a different Claude model.
        private const val MODEL = "claude-sonnet-5"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)

        conversationText = findViewById(R.id.conversationText)
        statusText = findViewById(R.id.statusText)
        micButton = findViewById(R.id.micButton)
        settingsButton = findViewById(R.id.settingsButton)

        tts = TextToSpeech(this, this)

        micButton.setOnClickListener { onMicTapped() }
        settingsButton.setOnClickListener { showApiKeyDialog() }

        if (getApiKey().isEmpty()) {
            showApiKeyDialog()
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale.US
        }
    }

    // ---------- API key storage ----------

    private fun getApiKey(): String = prefs.getString(KEY_API_KEY, "") ?: ""

    private fun saveApiKey(key: String) {
        prefs.edit().putString(KEY_API_KEY, key).apply()
    }

    private fun showApiKeyDialog() {
        val input = EditText(this)
        input.hint = "sk-ant-..."
        input.setText(getApiKey())

        AlertDialog.Builder(this)
            .setTitle("Anthropic API Key")
            .setMessage("Paste your Anthropic API key. It's stored only on this device.")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                saveApiKey(input.text.toString().trim())
                Toast.makeText(this, "API key saved", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- Mic / speech recognition ----------

    private fun onMicTapped() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                RECORD_AUDIO_PERMISSION_CODE
            )
            return
        }
        startListening()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == RECORD_AUDIO_PERMISSION_CODE &&
            grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            startListening()
        } else {
            Toast.makeText(this, "Microphone permission is required.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startListening() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak now...")
        }
        try {
            startActivityForResult(intent, SPEECH_REQUEST_CODE)
        } catch (e: Exception) {
            Toast.makeText(this, "Speech recognition not available on this device.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == SPEECH_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            val results = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spokenText = results?.get(0) ?: return
            appendConversation("You", spokenText)
            sendToAssistant(spokenText)
        }
    }

    // ---------- Conversation UI ----------

    private fun appendConversation(speaker: String, text: String) {
        conversation.append("$speaker: $text\n\n")
        runOnUiThread { conversationText.text = conversation.toString() }
    }

    private fun setStatus(text: String) {
        runOnUiThread { statusText.text = text }
    }

    // ---------- Calling the Claude API ----------

    private fun sendToAssistant(userText: String) {
        val apiKey = getApiKey()
        if (apiKey.isEmpty()) {
            appendConversation("Assistant", "Please set your API key first (tap 'Set API Key').")
            showApiKeyDialog()
            return
        }

        setStatus("Thinking...")
        micButton.isEnabled = false

        // Add user turn to history
        chatHistory.put(JSONObject().apply {
            put("role", "user")
            put("content", userText)
        })

        Thread {
            try {
                val replyText = callClaudeApi(apiKey, chatHistory)

                chatHistory.put(JSONObject().apply {
                    put("role", "assistant")
                    put("content", replyText)
                })

                appendConversation("Assistant", replyText)
                setStatus("")
                speak(replyText)
            } catch (e: Exception) {
                appendConversation("Assistant", "Error: ${e.message}")
                setStatus("")
            } finally {
                runOnUiThread { micButton.isEnabled = true }
            }
        }.start()
    }

    /**
     * Calls the Anthropic Messages API and returns the assistant's text reply.
     * Docs: https://docs.claude.com/en/api/messages
     */
    private fun callClaudeApi(apiKey: String, history: JSONArray): String {
        val url = URL("https://api.anthropic.com/v1/messages")
        val conn = url.openConnection() as HttpsURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("x-api-key", apiKey)
        conn.setRequestProperty("anthropic-version", "2023-06-01")
        conn.doOutput = true
        conn.connectTimeout = 20000
        conn.readTimeout = 30000

        val body = JSONObject().apply {
            put("model", MODEL)
            put("max_tokens", 1024)
            put("system", "You are a helpful, concise voice assistant. Keep answers short and conversational since they will be read aloud.")
            put("messages", history)
        }

        val os: OutputStream = conn.outputStream
        os.write(body.toString().toByteArray(Charsets.UTF_8))
        os.flush()
        os.close()

        val responseCode = conn.responseCode
        val stream = if (responseCode in 200..299) conn.inputStream else conn.errorStream
        val responseText = stream.bufferedReader().use { it.readText() }

        if (responseCode !in 200..299) {
            throw RuntimeException("API error ($responseCode): $responseText")
        }

        val json = JSONObject(responseText)
        val contentArray = json.getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until contentArray.length()) {
            val block = contentArray.getJSONObject(i)
            if (block.optString("type") == "text") {
                sb.append(block.optString("text"))
            }
        }
        return sb.toString().ifEmpty { "(no response)" }
    }

    // ---------- Text-to-speech ----------

    private fun speak(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "utteranceId")
    }

    override fun onDestroy() {
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }
}
