# Voice Assistant (Android)

A simple native Android voice assistant: tap the mic, speak, it sends your
words to Claude, speaks the reply back to you.

I can't compile this into a `.apk` myself (no Android build tools in my
environment), but building it yourself takes about 10 minutes and is free.

## What's inside
- Kotlin, plain Android Views (no Compose) — small and fast to build
- Speech-to-text via Android's built-in speech recognizer
- Text-to-speech via Android's built-in TTS
- Calls the Anthropic Messages API directly from the phone using an API key
  you paste in at first launch (stored locally on-device only)

## How to get the APK — Option A (Android Studio, easiest)

1. Install **Android Studio** (free): https://developer.android.com/studio
2. Open Android Studio → "Open" → select this `VoiceAssistant` folder.
3. Let Gradle sync (first time may download ~1-2 GB of build tools —
   this is normal and one-time).
4. Plug in your Android phone via USB (enable Developer Options + USB
   Debugging on the phone), or use an emulator.
5. Click the green ▶ Run button. The app installs and launches automatically.
6. To get a standalone `.apk` file you can share/download:
   Build menu → "Build Bundle(s) / APK(s)" → "Build APK(s)".
   Studio will show a notification with a "locate" link to the generated
   file, at:
   `app/build/outputs/apk/debug/app-debug.apk`
   Copy that file to your phone (or anywhere) — that's your installable APK.

## How to get the APK — Option B (command line, no Android Studio UI)

If you have the Android SDK command-line tools installed:

```bash
cd VoiceAssistant
./gradlew assembleDebug
```

(On Windows use `gradlew.bat assembleDebug`.) Output APK appears at:
`app/build/outputs/apk/debug/app-debug.apk`

Note: this project doesn't include the Gradle wrapper jar (binary file) —
opening it once in Android Studio auto-generates it, or run
`gradle wrapper` first if you have Gradle installed globally.

## First run
On first launch (or via the "Set API Key" button), paste your Anthropic
API key (starts with `sk-ant-...`), get one at https://console.anthropic.com.
Grant microphone permission when asked, then tap the mic and talk.

## Notes / things you may want to customize
- Model used: `claude-sonnet-5` — change the `MODEL` constant in
  `MainActivity.kt` if you want a different one.
- The API key is stored in unencrypted SharedPreferences for simplicity.
  For anything beyond personal testing, move it to Android's
  EncryptedSharedPreferences or route calls through your own backend so the
  key never lives on-device.
- Calling a paid API directly from a shipped app means anyone who
  decompiles the app could extract your key. Fine for personal use;
  not recommended before publishing publicly.
